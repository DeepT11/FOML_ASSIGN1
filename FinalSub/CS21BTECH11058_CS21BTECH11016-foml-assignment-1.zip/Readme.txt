Sl. no. : 84
Tejal Kulkarni - CS21BTECH11058
Deepshikha - CS21BTECH11016

##Steps to run the Question_1.ipynb notebook:
1.) Open the notebook in Google Colab.
2.) In files(session storage) section upload the dataset data.csv provided in the zip file of the Assignment submission.
3.) You are good to go!
